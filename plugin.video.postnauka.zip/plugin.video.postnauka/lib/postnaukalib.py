import exceptions
import urllib
import urlparse
import xbmc
import sys
import os
import re
import requests

from bs4 import BeautifulSoup

cache_plugin_path = xbmc.translatePath(
        "special://home/addons/script.common.plugin.cache/")
storage_path = os.path.join(cache_plugin_path, "lib")
sys.path.append(storage_path)
try:
    from StorageServer import StorageServer
except:
    import lib.storageserverdummy as StorageServer


youtubeAddonUrl = ("plugin://plugin.video.youtube/"
                   "?path=/root/video&action=play_video&videoid=")

YTID = re.compile("http://www.youtube.com/embed/([^?]+)?")
PAGE = re.compile(".*/page/(\d+)")

MAIN_MENU = (
            ("Видео", "allvideos"),
            ("Лекции", "alllectures"),
            ("Науки", "science"),
            ("Курсы", "allcourses")
 )

SCIENCES = {
    "biology": "Биология",
    "pravo": "Право",
    "language": "Язык",
    "physics": "Физика",
    "philosophy": "Философия",
    "astronomy": "Астрономия",
    "culture": "Культура",
    "istoriya": "История",
    "sociology": "Социология",
    "ekonomika": "Экономика",
    "medicine": "Медицина",
    "psihologiya": "Психология",
    "chemistry": "Химия",
    "technology": "Технологии",
    "math": "Математика",
}

SITE = "http://postnauka.ru/"

URLS = {
    "allvideos": SITE + "video",
    "allcourses": SITE + "courses",
    "alllectures": SITE + "lectures",

}

XBOX = xbmc.getCondVisibility("System.Platform.xbox")


def dump(a, t):
    with open(xbmc.translatePath("special://home/temp/") + a, "w") as f:
        f.write(t)


def requests_debug():
    import logging

    # these two lines enable debugging at httplib level
    # (requests->urllib3->httplib)
    # you will see the REQUEST, including HEADERS and DATA, and RESPONSE with
    # HEADERS but without DATA.
    # the only thing missing will be the response.body which is not logged.
    import httplib
    httplib.HTTPConnection.debuglevel = 1

    logging.basicConfig()
    logging.getLogger().setLevel(logging.DEBUG)
    requests_log = logging.getLogger("requests.packages.urllib3")
    requests_log.setLevel(logging.DEBUG)
    requests_log.propagate = True


class PostnaukaError(exceptions.BaseException):
    pass


class MultipleActions(PostnaukaError):
    pass


class WebError(PostnaukaError):
    pass


def get_plugin_name(url):
    return urlparse.urlparse(url).netloc


def build_url(base_url, query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))


def digitize(s):
    return "".join([i for i in s if i.isdigit()])


def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            # Must be encoded in UTF-8
            v.decode('utf8')
        out_dict[k] = v
    return out_dict


class Base:
    info = None


class Logger(Base):
    levels = {
        xbmc.LOGDEBUG: "DEBUG",
        xbmc.LOGINFO: "INFO",
        xbmc.LOGERROR: "ERROR",
    }

    def __init__(self):
        plugin_name, addon_handle, addon = Base.info
        self.prefix = "{base}[{addon_handle}]: ".format(
            base=plugin_name,
            addon_handle=addon_handle)
        self.debug_enabled = addon.getSetting("debug_enabled")
        if self.debug_enabled:
            requests_debug()

    def __unify(self, msg):
        if isinstance(msg, unicode):
            return msg.encode('utf-8')
        else:
            return msg

    def __print_log(self, msgs, level):
            msgs = [repr(self.__unify(m)) for m in msgs]
            level_prefix = self.levels[level]
            log_message = "{prefix} [{level_prefix}] {msgs}".format(
                prefix=self.prefix,
                level_prefix=level_prefix,
                msgs=repr(" ".join(msgs)))
            # xbmc.log(log_message, level=level)
            print log_message

    def debug(self, *msgs):
        if self.debug_enabled:
            self.__print_log(msgs, level=xbmc.LOGDEBUG)

    def info(self, *msgs):
        self.__print_log(msgs, level=xbmc.LOGINFO)

    def error(self, *msgs):
        self.__print_log(msgs, level=xbmc.LOGERROR)


class Web:
    def __init__(self):
        self.url = None
        self.log = Logger()

    def get_url(self, url):
        self.url = url
        self.log.debug("Connect to URL={url}".format(url=self.url))
        try:
            request = requests.get(self.url)
            content = request.content
        except requests.HTTPError:
            self.log.error("Can not connect to {}".format(self.url))
            raise WebError("URL unreachable")
        if not content:
            self.log.error("Can not retrieve {}".format(self.url))
            raise WebError("HTTP page is empty")
        self.log.debug("URL {url} was retrieved successfully!".format(
            url=self.url))
        return content


class Parser:
    def __init__(self):
        self.log = Logger()
        self.parser = "html.parser"

    def get_video_details_from(self, text):
        log = self.log
        soup = BeautifulSoup(text, self.parser)
        link = soup.find("meta", itemprop="url").get("content")
        video = {"url": link}
        log.debug("Video URL: {}".format(video["url"]))
        iframe = soup.find("iframe").attrs["src"]
        log.debug("IFRAME: {}".format(str(iframe)))
        if "http://www.youtube.com/embed" in iframe:
            youtube_id_match = YTID.search(iframe)
        if not youtube_id_match:
            return None
        video["id"] = youtube_id_match.group(1)
        log.debug("Video Youtube ID: {}".format(video["id"]))
        video["play"] = youtubeAddonUrl + video["id"]
        video["title"] = soup.find("meta", itemprop="name").get("content")
        video["img"] = soup.find("meta", itemprop="image").get("content")
        video["summary"] = soup.find("meta", itemprop="description").get(
            "content")
        video["date"] = soup.find("div", class_="p-data").contents[0]
        video["category"] = soup.select('h3[class="p-cat"] > a')[0].text
        video["views"] = int(
            digitize(soup.findAll("div", class_="p-comms")[1].text))
        video["tags"] = list(soup.find("div", id="p-tags").strings)
        return video

    def extract_video_links(self, text):
        links = []
        soup = BeautifulSoup(text, self.parser)
        lis = soup.select('div[id="project"] > li')
        for li in lis:
            link = li.find("a").attrs["href"]
            links.append(link)
        if links:
            self.log.debug("Succeeded to get video links from page")
        else:
            self.log.error("Failed to get video links from page!")
        return links

    def extract_video_links_science(self, text):
        soup = BeautifulSoup(text, self.parser)
        lis = soup.select('div[id="m"] > li a[title]')
        links = list(set([i["href"] for i in lis]))
        self.log.debug("Extracted {} links from page".format(len(links)))
        links = [link for link in links if
                 "/video/" in link or
                 "/lecture/" in link or
                 "/course/" in link
                 ]
        return links

    def get_next_and_total_pages(self, text):
        dump("test", text)
        soup = BeautifulSoup(text, self.parser)
        total_pages = current_page = next_page = None
        current_page = int(digitize(soup.find("span", class_="current").text))
        next_page_tag = soup.find("a", class_="nextpostslink")
        if next_page_tag:
            url = next_page_tag["href"]
            next_page = int(digitize(PAGE.search(url).group(1)))
        else:
            next_page = None
            total_pages = current_page
        if not total_pages:
            last_tag = soup.find("a", class_="last")
            if not last_tag and next_page:
                larger = max(
                    [int(i.text)
                     for i in soup.findAll("a", class_="page larger")])
                total_pages = max(next_page, larger)
            else:
                url = last_tag["href"]
                total_pages = int(digitize(PAGE.search(url).group(1)))
        self.log.debug("Current:{}, Next:{}, Total:{}".format(
            current_page, next_page, total_pages))
        return current_page, next_page, total_pages
